#!/bin/sh

echo "Patate"

javac -cp /applis/sicstus-4.3.3/lib/sicstus-4.3.3/bin/jasper.jar:. *.java 

java -cp /applis/sicstus-4.3.3/lib/sicstus-4.3.3/bin/jasper.jar:. main2 $4 &

./joueur $1 $2 $3 $4



