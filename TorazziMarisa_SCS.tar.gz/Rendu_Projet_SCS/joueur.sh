#!/bin/sh

javac -cp /applis/sicstus-4.3.3/lib/sicstus-4.3.3/bin/jasper.jar:. MoteurIA/*.java 
cd MoteurIA


if [ $4 -eq 0 ]
then 

	java -cp /applis/sicstus-4.3.3/lib/sicstus-4.3.3/bin/jasper.jar:. main2 $4 &
	cd ..
	cd Joueur
	./joueur $1 $2 $3 $4

else

	java -cp /applis/sicstus-4.3.3/lib/sicstus-4.3.3/bin/jasper.jar:. main2 4212 &
	cd ..
	cd Joueur
	./joueur $1 $2 $3 4212
fi
